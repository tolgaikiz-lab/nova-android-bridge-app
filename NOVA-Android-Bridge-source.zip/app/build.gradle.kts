plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

dependencies { implementation("androidx.core:core-ktx:1.15.0") }

android { namespace = "com.tolgaikiz.novabridge"; compileSdk = 35
    defaultConfig { applicationId = "com.tolgaikiz.novabridge"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
}
