package com.tolgaikiz.novabridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
  private lateinit var web: WebView
  private var pending: PermissionRequest? = null
  private val io = Executors.newSingleThreadExecutor()
  override fun onCreate(state: Bundle?) { super.onCreate(state)
    web=WebView(this); setContentView(web)
    web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.mediaPlaybackRequiresUserGesture=false
    web.addJavascriptInterface(Bridge(),"NovaAndroid")
    web.webViewClient=object:WebViewClient(){ override fun shouldOverrideUrlLoading(v:WebView,u:String)=false }
    web.webChromeClient=object:WebChromeClient(){ override fun onPermissionRequest(r:PermissionRequest){
      if(r.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
        else { pending=r; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),41) }
      } else r.deny()
    }}
    web.loadUrl("https://nova-asistan.tolgaikiz54.workers.dev/")
  }
  override fun onRequestPermissionsResult(code:Int,p:Array<out String>,out:IntArray){ super.onRequestPermissionsResult(code,p,out); val r=pending?:return; pending=null; if(code==41&&out.firstOrNull()==PackageManager.PERMISSION_GRANTED)r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))else r.deny() }
  inner class Bridge {
    @JavascriptInterface fun shareBase64(data:String,name:String,mime:String,contact:String,message:String){ io.execute { try {
      val folder=File(cacheDir,"reports").apply{mkdirs()}; val safe=name.replace(Regex("[^A-Za-z0-9._-]"),"_").ifBlank{"nova_rapor.xlsx"}; val file=File(folder,safe)
      file.writeBytes(Base64.decode(data,Base64.DEFAULT)); runOnUiThread{share(file,mime,contact,message)}
    }catch(_:Exception){runOnUiThread{web.evaluateJavascript("alert('Rapor dosyası hazırlanamadı.');",null)}}} }
  }
  private fun share(file:File,mime:String,contact:String,message:String){
    val uri:Uri=FileProvider.getUriForFile(this,"$packageName.files",file)
    val send=Intent(Intent.ACTION_SEND).apply{type=mime;setPackage("com.whatsapp");putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,message);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
    try{startActivity(Intent.createChooser(send,"${contact.ifBlank{"WhatsApp"}} için raporu paylaş"))}catch(_:Exception){startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,message);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Raporu paylaş"))}
  }
}
