package com.tolgaikiz.novabridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private companion object { const val MICROPHONE_REQUEST = 41 }
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(NovaBridge(), "NovaAndroid")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = false
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        request.deny()
                    } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        pendingWebPermission = request
                        requestMicrophonePermission()
                    }
                }
            }
        }
        requestMicrophonePermission()
        webView.loadUrl("https://nova-asistan.tolgaikiz54.workers.dev/")
    }

    private fun requestMicrophonePermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MICROPHONE_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        val request = pendingWebPermission ?: return
        pendingWebPermission = null
        if (requestCode == MICROPHONE_REQUEST && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
    }

    inner class NovaBridge {
        @JavascriptInterface
        fun shareBase64(base64: String, fileName: String, mimeType: String, contactName: String, message: String) {
            io.execute {
                try {
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "nova_rapor.xlsx" }
                    val folder = File(cacheDir, "reports").apply { mkdirs() }
                    val file = File(folder, safeName)
                    file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                    runOnUiThread { openWhatsAppShare(file, mimeType, contactName, message) }
                } catch (_: Exception) { runOnUiThread { webView.evaluateJavascript("alert('Rapor dosyası hazırlanamadı.');", null) } }
            }
        }
    }

    private fun openWhatsAppShare(file: File, mimeType: String, contactName: String, message: String) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            setPackage("com.whatsapp")
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(intent, "${contactName.ifBlank { "WhatsApp" }} için raporu paylaş")) }
        catch (_: Exception) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type=mimeType; putExtra(Intent.EXTRA_STREAM,uri); putExtra(Intent.EXTRA_TEXT,message); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Raporu paylaş")) }
    }
}
