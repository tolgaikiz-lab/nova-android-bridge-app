# NOVA Android Köprüsü

Bu uygulama NOVA'da oluşturulan Excel veya PDF raporlarını telefonun indirme alanına bırakmadan WhatsApp paylaşımına ekler. Son gönderim WhatsApp ekranında kullanıcıdadır.

## Telefonda APK oluşturma

1. GitHub'da `nova-android-bridge` adında **Private** depo oluştur.
2. Bu klasördeki dosyaları depoya yükle.
3. GitHub'da Actions > NOVA Android APK > Run workflow seç.
4. İşlem bittiğinde Artifacts bölümünden `NOVA-Android-Bridge-APK` dosyasını telefona indir ve kur.
5. Uygulamada mikrofon iznini ver. NOVA'da rapor oluşturduktan sonra WhatsApp paylaşım düğmesine dokun.

Not: WhatsApp'ın güvenlik modeli nedeniyle son gönderim kullanıcıdadır. Uygulama dosyayı ekli olarak WhatsApp paylaşımına verir; indirilenler klasöründen dosya seçme gerekmez.
