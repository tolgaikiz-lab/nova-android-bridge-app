# NOVA Android Köprüsü

NOVA'nın hazırladığı Excel/PDF dosyasını indirilenlere bırakmadan WhatsApp paylaşımına ekler. Son gönderim kullanıcıdadır.

GitHub'da **Actions > NOVA Android APK > Run workflow** seçilir. İş bittiğinde Artifacts bölümündeki `NOVA-Android-Bridge-APK` telefona indirilip kurulur.
